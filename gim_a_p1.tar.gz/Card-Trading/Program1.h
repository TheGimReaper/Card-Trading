#ifndef PROGRAM1_H
#define PROGRAM1_H

#include <iostream>
#include <string.h>
#include <vector>
#include <fstream>
#include <ctime>
#include <unistd.h>
#include <cstdio>

class Card
{
	public:
		Card(std::string n, int m, int c);
		std::string name;
		int mPrice;
		int cost;
				
};


#endif
